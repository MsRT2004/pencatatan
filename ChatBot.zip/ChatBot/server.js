require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');

// Lock file — cegah multiple instance
const LOCK_FILE = path.join(__dirname, 'bot.lock');
if (fs.existsSync(LOCK_FILE)) {
    const pid = fs.readFileSync(LOCK_FILE, 'utf8').trim();
    try {
        process.kill(parseInt(pid), 0); // cek proses masih hidup
        console.error(`Bot sudah jalan (PID ${pid}). Kill dulu: taskkill /F /PID ${pid}`);
        process.exit(1);
    } catch {
        // Proses mati, hapus lock
    }
}
fs.writeFileSync(LOCK_FILE, String(process.pid));
process.on('exit', () => { try { fs.unlinkSync(LOCK_FILE); } catch {} });
process.on('SIGINT', () => process.exit());
process.on('SIGTERM', () => process.exit());

const bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, { polling: true });

// Multi API key — pisah koma di .env, auto rotate kalau error
const API_KEYS = process.env.GEMINI_API_KEY.split(',').map(k => k.trim()).filter(Boolean);
let currentKeyIndex = 0;

// Model fallback per key — coba dari paling stabil
const MODEL_FALLBACKS = ['gemini-2.5-flash-lite', 'gemini-flash-latest', 'gemini-3.6-flash'];

function getVisionModel(modelName) {
    const genAI = new GoogleGenerativeAI(API_KEYS[currentKeyIndex]);
    return genAI.getGenerativeModel({ model: modelName || MODEL_FALLBACKS[0] });
}

function rotateKey() {
    currentKeyIndex = (currentKeyIndex + 1) % API_KEYS.length;
    console.log(`[API] Rotate ke key ${currentKeyIndex + 1}/${API_KEYS.length}`);
}

console.log(`[API] ${API_KEYS.length} Gemini API key loaded`);

const DB_PATH = path.join(__dirname, 'data.json');
const PHOTOS_DIR = path.join(__dirname, 'photos');
if (!fs.existsSync(PHOTOS_DIR)) fs.mkdirSync(PHOTOS_DIR);

const userCounters = new Map();

function loadData() {
    if (!fs.existsSync(DB_PATH)) return [];
    try { return JSON.parse(fs.readFileSync(DB_PATH, 'utf8')); }
    catch { return []; }
}

function saveData(data) {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
}

// Parse 1 block teks jadi fields
function parseSingle(text) {
    const get = (key) => {
        const match = text.match(new RegExp('(?:^|[^a-zA-Z])(' + key + ')\\s*:\\s*(.+)', 'im'));
        return match ? match[2].trim() : '-';
    };
    return {
        nama: get('Nama'),
        link: get('Link Profil') || get('Link'),
        email: get('Email'),
        tgl_lahir: get('Tanggal Lahir') || get('Tanggal'),
        key: get('Key'),
        kode_cadangan: get('Kode cadangan') || get('Kode')
    };
}

// Parse banyak block [FbXXX] dari teks copasan
function parseEntries(text) {
    const entries = [];
    
    // Split per [FbXXX] atau FbXXX block (bisa ada/tanpa kurung siku)
    const parts = text.split(/(?:\[?Fb\s*(\d+)\]?)/gi);
    
    if (parts.length >= 3) {
        for (let i = 1; i < parts.length; i += 2) {
            const num = parseInt(parts[i]);
            const body = parts[i + 1] || '';
            const fields = parseSingle(body);
            // Terima selama ada minimal 1 field selain "-"
            const hasAny = Object.values(fields).some(v => v && v !== '-');
            if (hasAny) {
                entries.push({ id: `Fb${num}`, num, ...fields });
            }
        }
    }
    
    // Fallback: teks tanpa FbXXX tapi ada data
    if (entries.length === 0) {
        const fields = parseSingle(text);
        const hasAny = Object.values(fields).some(v => v && v !== '-');
        if (hasAny) entries.push(fields);
    }
    
    return entries;
}

function hasData(text) {
    if (!text) return false;
    return /Nama\s*:/i.test(text) || /Email\s*:/i.test(text) || /Key\s*:/i.test(text);
}

function formatEntry(e) {
    return `[${e.id}]\nNama : ${e.nama}\nLink Profil : ${e.link}\nEmail : ${e.email}\nTanggal Lahir : ${e.tgl_lahir}\nKey : ${e.key}\nKode cadangan : ${e.kode_cadangan}`;
}

// Kirim teks panjang — auto split per 3900 char
async function sendLong(chatId, text) {
    if (text.length <= 4000) {
        await bot.sendMessage(chatId, text);
        return;
    }
    // Split di newline terdekat
    let start = 0;
    while (start < text.length) {
        let end = Math.min(start + 3900, text.length);
        if (end < text.length) {
            const lastNl = text.lastIndexOf('\n', end);
            if (lastNl > start) end = lastNl;
        }
        await bot.sendMessage(chatId, text.substring(start, end).trim());
        start = end;
    }
}

function downloadBuffer(url) {
    return new Promise((resolve, reject) => {
        const client = url.startsWith('https') ? https : http;
        client.get(url, (res) => {
            const chunks = [];
            res.on('data', c => chunks.push(c));
            res.on('end', () => resolve(Buffer.concat(chunks)));
            res.on('error', reject);
        }).on('error', reject);
    });
}

// Gemini Vision — auto retry dengan key rotation + model fallback
async function readImageText(imageBuffer, extraText) {
    const base64 = imageBuffer.toString('base64');
    const prompt = `Lihat gambar ini. Screenshot data akun Facebook (profil, kode pemulihan, email, dll).

Teks tambahan: ${extraText || '(tidak ada)'}

Output HARUS format ini (isi yang ketemu, yang tidak ada isi dengan tanda strip -):
Nama : [nama]
Link Profil : [URL facebook lengkap]
Email : [email]
Tanggal Lahir : [tanggal lahir]
Key : [2FA key]
Kode cadangan : [kode recovery, pisah koma]

Hanya format di atas, tanpa penjelasan.`;

    const content = [
        { inlineData: { mimeType: 'image/jpeg', data: base64 } },
        prompt
    ];

    // Coba semua key x semua model
    for (let attempt = 0; attempt < API_KEYS.length; attempt++) {
        for (const modelName of MODEL_FALLBACKS) {
            try {
                const model = getVisionModel(modelName);
                const result = await model.generateContent(content);
                console.log(`[API key ${currentKeyIndex + 1}] OK with ${modelName}`);
                return result.response.text();
            } catch (err) {
                console.error(`[API key ${currentKeyIndex + 1}] ${modelName}:`, err.message.slice(0, 80));
                // Model not found for this key, try next model
                if (err.message.includes('404')) continue;
                // Overloaded or quota — try next model first
                if (err.message.includes('503') || err.message.includes('429') || err.message.includes('quota')) continue;
                // 403 denied — skip this key entirely
                if (err.message.includes('403')) break;
                continue;
            }
        }
        rotateKey();
    }
    console.error('[API] Semua key & model habis/error');
    return null;
}

// Simpan entries — bulk atau single
async function saveEntriesBulk(chatId, userId, entriesText, photoPath) {
    const entries = parseEntries(entriesText);
    console.log(`[saveEntriesBulk] Parsed ${entries.length} entries`);
    
    if (entries.length === 0) {
        await bot.sendMessage(chatId, 'Data tidak lengkap. Pastikan format:\n[Fb234]\nNama : ...\nEmail : ...\ndst');
        return;
    }

    let counter = userCounters.get(userId);
    const data = loadData();
    const lines = [];
    let maxIdNum = 0;

    for (const item of entries) {
        let id, entry;
        
        if (item.id) {
            id = item.id;
            maxIdNum = Math.max(maxIdNum, item.num);
            entry = { ...item };
            delete entry.num;
        } else {
            if (!counter) {
                await bot.sendMessage(chatId, 'Ketik dulu: mulai dari [nomor]\nAtau kirim dengan format [FbXXX]');
                return;
            }
            id = `Fb${counter}`;
            maxIdNum = Math.max(maxIdNum, counter);
            entry = { id, ...item };
            counter++;
        }

        if (photoPath) entry.photo = photoPath;

        const idx = data.findIndex(d => d.id === id);
        if (idx >= 0) data[idx] = entry;
        else data.push(entry);

        lines.push(formatEntry(entry));
    }

    saveData(data);

    if (maxIdNum > 0) {
        userCounters.set(userId, maxIdNum + 1);
    }

    const nextCounter = userCounters.get(userId);
    const reply = lines.join('\n\n') + `\n\n──────────────────\n✅ ${entries.length} data tersimpan.\nBerikutnya: Fb${nextCounter} | Total: ${data.length}`;
    
    await sendLong(chatId, reply);
}

// === HANDLERS ===

bot.onText(/\/start/, (msg) => {
    const counter = userCounters.get(msg.from.id);
    bot.sendMessage(msg.chat.id,
`Bot Pencatat Akun

Cara pakai:
1. Ketik: mulai dari [nomor]
2. Kirim foto screenshot / foto+caption / teks data
3. Bot otomatis baca dan list

Counter: ${counter ? 'Fb' + counter : 'Belum diset'}
Total: ${loadData().length} akun`);
});

bot.onText(/mulai dari (\d+)/i, (msg, match) => {
    const num = parseInt(match[1]);
    userCounters.set(msg.from.id, num);
    bot.sendMessage(msg.chat.id, `Counter dimulai dari Fb${num}`);
});

// Media group batching
const mediaGroups = new Map();

bot.on('photo', async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const groupId = msg.media_group_id;

    if (!groupId) {
        await processSinglePhoto(chatId, userId, msg);
        return;
    }

    if (!mediaGroups.has(groupId)) {
        mediaGroups.set(groupId, { photos: [], caption: msg.caption || '', chatId, userId });
    }

    const group = mediaGroups.get(groupId);
    group.photos.push(msg.photo[msg.photo.length - 1].file_id);
    if (msg.caption) group.caption = msg.caption;

    if (group.timer) clearTimeout(group.timer);
    group.timer = setTimeout(() => processMediaGroup(groupId), 1500);
});

async function processSinglePhoto(chatId, userId, msg) {
    try {
        const fileId = msg.photo[msg.photo.length - 1].file_id;
        const fileLink = await bot.getFileLink(fileId);
        const imageBuffer = await downloadBuffer(fileLink);

        const counter = userCounters.get(userId);
        let photoPath = null;
        if (counter) {
            photoPath = path.join(PHOTOS_DIR, `Fb${counter}.jpg`);
            fs.writeFileSync(photoPath, imageBuffer);
        }

        const caption = msg.caption || '';
        console.log(`[Foto tunggal] Gemini Vision...`);
        const extracted = await readImageText(imageBuffer, caption);

        if (extracted && hasData(extracted)) {
            await saveEntriesBulk(chatId, userId, extracted, photoPath);
        } else if (hasData(caption)) {
            await saveEntriesBulk(chatId, userId, caption, photoPath);
        } else {
            bot.sendMessage(chatId, 'Data tidak lengkap.');
        }
    } catch (err) {
        console.error('Error foto:', err.message);
        bot.sendMessage(chatId, 'Gagal proses gambar.');
    }
}

async function processMediaGroup(groupId) {
    const group = mediaGroups.get(groupId);
    mediaGroups.delete(groupId);
    if (!group) return;

    const { photos, caption, chatId, userId } = group;
    console.log(`[Media group] ${photos.length} foto, Gemini Vision...`);

    try {
        const buffers = [];
        for (const fileId of photos) {
            const fileLink = await bot.getFileLink(fileId);
            buffers.push(await downloadBuffer(fileLink));
        }

        const counter = userCounters.get(userId);
        let photoPath = null;
        if (counter) {
            photoPath = path.join(PHOTOS_DIR, `Fb${counter}.jpg`);
            fs.writeFileSync(photoPath, buffers[0]);
        }

        const parts = buffers.map(buf => ({
            inlineData: { mimeType: 'image/jpeg', data: buf.toString('base64') }
        }));

        const prompt = `Lihat semua ${photos.length} gambar. Screenshot data 1 akun FB.

Teks tambahan: ${caption || '(tidak ada)'}

Gabungkan semua info, output HANYA format ini (yang tidak ada isi tanda strip -):
Nama : [nama]
Link Profil : [URL facebook]
Email : [email]
Tanggal Lahir : [tanggal lahir]
Key : [2FA key]
Kode cadangan : [kode recovery, pisah koma]

Hanya format di atas.`;

        parts.push(prompt);
        let extracted = null;
        for (let attempt = 0; attempt < API_KEYS.length; attempt++) {
            for (const modelName of MODEL_FALLBACKS) {
                try {
                    const model = getVisionModel(modelName);
                    const result = await model.generateContent(parts);
                    extracted = result.response.text();
                    console.log(`[Media group] OK with ${modelName} key ${currentKeyIndex + 1}`);
                    break;
                } catch (err) {
                    console.error(`[API key ${currentKeyIndex + 1}] ${modelName}:`, err.message.slice(0, 80));
                    if (err.message.includes('404')) continue;
                    if (err.message.includes('503') || err.message.includes('429') || err.message.includes('quota')) continue;
                    if (err.message.includes('403')) break;
                    continue;
                }
            }
            if (extracted) break;
            rotateKey();
        }

        if (hasData(extracted)) {
            console.log(`[Media group] OK`);
            await saveEntriesBulk(chatId, userId, extracted, photoPath);
        } else if (hasData(caption)) {
            await saveEntriesBulk(chatId, userId, caption, photoPath);
        } else {
            bot.sendMessage(chatId, 'Data tidak lengkap.');
        }
    } catch (err) {
        console.error('Error media group:', err.message);
        bot.sendMessage(chatId, 'Gagal proses gambar.');
    }
}

// Teks biasa
bot.on('message', async (msg) => {
    if (!msg.text || msg.text.startsWith('/')) return;
    if (/mulai dari \d+/i.test(msg.text)) return;
    if (!hasData(msg.text) && !/\[Fb\d+\]/i.test(msg.text)) return;
    
    console.log(`[Teks] ${msg.text.length} char`);
    try {
        await saveEntriesBulk(msg.chat.id, msg.from.id, msg.text, null);
    } catch (err) {
        console.error('Error teks:', err.message);
        bot.sendMessage(msg.chat.id, 'Gagal proses data.');
    }
});

// /lihat
bot.onText(/\/lihat (.+)/, (msg, match) => {
    const entry = loadData().find(d => d.id.toLowerCase() === match[1].trim().toLowerCase());
    bot.sendMessage(msg.chat.id, entry ? formatEntry(entry) : 'Tidak ditemukan.');
});

// /cari
bot.onText(/\/cari (.+)/, async (msg, match) => {
    const kw = match[1].toLowerCase();
    const results = loadData().filter(d =>
        d.nama.toLowerCase().includes(kw) || d.email.toLowerCase().includes(kw) || d.id.toLowerCase().includes(kw)
    );
    if (results.length === 0) { bot.sendMessage(msg.chat.id, 'Tidak ditemukan.'); return; }
    await sendLong(msg.chat.id, results.slice(0, 10).map(formatEntry).join('\n\n'));
});

// /hapus
bot.onText(/\/hapus (.+)/, (msg, match) => {
    const data = loadData();
    const idx = data.findIndex(d => d.id.toLowerCase() === match[1].trim().toLowerCase());
    if (idx < 0) { bot.sendMessage(msg.chat.id, 'Tidak ditemukan.'); return; }
    const removed = data.splice(idx, 1)[0];
    saveData(data);
    bot.sendMessage(msg.chat.id, `Dihapus: [${removed.id}] ${removed.nama}`);
});

// /list
bot.onText(/\/list/, async (msg) => {
    const data = loadData();
    if (data.length === 0) { bot.sendMessage(msg.chat.id, 'Belum ada data.'); return; }
    const text = `List (${data.length}):\n\n` + data.map(d => `[${d.id}] ${d.nama}`).join('\n');
    await sendLong(msg.chat.id, text);
});

// /export
bot.onText(/\/export/, (msg) => {
    const data = loadData();
    if (data.length === 0) { bot.sendMessage(msg.chat.id, 'Belum ada data.'); return; }
    const text = data.map(formatEntry).join('\n\n' + '─'.repeat(30) + '\n\n');
    const p = path.join(__dirname, 'export.txt');
    fs.writeFileSync(p, text, 'utf8');
    bot.sendDocument(msg.chat.id, p, { caption: `${data.length} akun` });
});

bot.on('polling_error', (err) => console.error('Polling error:', err.code));
bot.on('error', (err) => console.error('Bot error:', err.message));

bot.getMe().then((me) => {
    console.log(`Bot terhubung: @${me.username} | ${loadData().length} akun`);
});
